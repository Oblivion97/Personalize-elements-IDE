# Coding Fonts

There are many coding fonts out there. Among them, these fonts are my favorites ones. I highly recommend buying the premium ones.

## Fonts List

- **Dank Mono** [(Original Link)](https://dank.sh/)
- **Fira Code** [(Original Repo)](https://github.com/tonsky/FiraCode)
- **Gintronic** [(Original Link)](https://markfromberg.com/projects/gintronic/)
- **Monego** [(Original Repo)](https://github.com/cseelus/monego)
- **Operator Mono Lig** [(Original Operator Mono)](https://www.cufonfonts.com/font/operator-mono)
